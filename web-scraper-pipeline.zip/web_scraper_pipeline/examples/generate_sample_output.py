"""Generate SAMPLE output offline using a simulated copy of the site's markup.

This is for demonstration/testing only - the data is synthetic.
For real data run:  python -m scraper
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from scraper import pipeline                      # noqa: E402
from scraper.fetcher import Fetcher               # noqa: E402
from tests.fakesite import FakeSession, make_site  # noqa: E402

fetcher = Fetcher(session=FakeSession(make_site(pages=5, per_page=20)), delay=0, respect_robots=False)
paths, summary = pipeline.run(fetcher, pipeline.DEFAULT_START_URL, 50, ROOT / "output", prefix="sample_")
print(paths["report"].read_text())
