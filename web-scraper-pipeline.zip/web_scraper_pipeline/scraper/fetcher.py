"""Polite HTTP fetching: rate limiting, custom headers, retries with backoff, robots.txt."""

from __future__ import annotations

import logging
import time
from typing import Callable, Dict, Optional
from urllib.parse import urljoin, urlparse
from urllib.robotparser import RobotFileParser

import requests

log = logging.getLogger(__name__)

DEFAULT_HEADERS = {
    "User-Agent": "EducationalScraper/1.0 (+https://github.com/your-username/web-scraper-pipeline)",
    "Accept": "text/html,application/xhtml+xml",
    "Accept-Language": "en-US,en;q=0.9",
}
RETRY_STATUS = {429, 500, 502, 503, 504}


class FetchError(Exception):
    """Raised when a page cannot be fetched after all retries (or is disallowed)."""


class Fetcher:
    def __init__(
        self,
        session: Optional[requests.Session] = None,
        delay: float = 1.0,
        max_retries: int = 3,
        backoff: float = 2.0,
        timeout: float = 10.0,
        headers: Optional[Dict[str, str]] = None,
        respect_robots: bool = True,
        sleep: Callable[[float], None] = time.sleep,
        clock: Callable[[], float] = time.monotonic,
    ):
        self.session = session or requests.Session()
        self.session.headers.update(headers or DEFAULT_HEADERS)
        self.delay, self.max_retries, self.backoff, self.timeout = delay, max_retries, backoff, timeout
        self.respect_robots = respect_robots
        self._sleep, self._clock = sleep, clock
        self._last_request: Optional[float] = None
        self._robots: Dict[str, Optional[RobotFileParser]] = {}
        self.requests_made = 0

    # ---- rate limiting ----
    def _throttle(self) -> None:
        if self._last_request is not None:
            wait = self.delay - (self._clock() - self._last_request)
            if wait > 0:
                self._sleep(wait)
        self._last_request = self._clock()

    # ---- robots.txt ----
    def allowed(self, url: str) -> bool:
        if not self.respect_robots:
            return True
        parts = urlparse(url)
        root = f"{parts.scheme}://{parts.netloc}"
        if root not in self._robots:
            parser: Optional[RobotFileParser] = RobotFileParser()
            try:
                self._throttle()
                resp = self.session.get(urljoin(root, "/robots.txt"), timeout=self.timeout)
                if resp.status_code == 200:
                    parser.parse(resp.text.splitlines())
                else:
                    parser = None  # no robots.txt -> everything allowed
            except requests.RequestException:
                parser = None
            self._robots[root] = parser
        parser = self._robots[root]
        ua = self.session.headers.get("User-Agent", "*")
        return True if parser is None else parser.can_fetch(ua, url)

    # ---- fetching ----
    def get(self, url: str) -> str:
        if not self.allowed(url):
            raise FetchError(f"robots.txt disallows fetching {url}")
        last_error = "unknown error"
        for attempt in range(1, self.max_retries + 2):
            self._throttle()
            self.requests_made += 1
            try:
                resp = self.session.get(url, timeout=self.timeout)
            except (requests.ConnectionError, requests.Timeout) as exc:
                last_error = f"{type(exc).__name__}: {exc}"
            else:
                if resp.status_code == 200:
                    resp.encoding = "utf-8"
                    return resp.text
                if resp.status_code not in RETRY_STATUS:
                    raise FetchError(f"{url}: HTTP {resp.status_code}")
                last_error = f"HTTP {resp.status_code}"
                retry_after = resp.headers.get("Retry-After", "")
                if retry_after.isdigit():
                    self._sleep(min(int(retry_after), 60))
            if attempt <= self.max_retries:
                pause = self.backoff ** (attempt - 1)
                log.warning("%s failed (%s); retry %d/%d in %.1fs", url, last_error, attempt, self.max_retries, pause)
                self._sleep(pause)
        raise FetchError(f"{url}: giving up after {self.max_retries + 1} attempts ({last_error})")
