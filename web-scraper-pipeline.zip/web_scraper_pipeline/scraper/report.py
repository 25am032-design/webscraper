"""Automated summary statistics report."""

from __future__ import annotations

import statistics
from collections import Counter
from typing import Any, Dict, List

from scraper.parser import Book


def summarize(books: List[Book]) -> Dict[str, Any]:
    if not books:
        return {"total_books": 0}
    prices = [b.price_gbp for b in books]
    by_rating: Dict[int, List[float]] = {}
    for b in books:
        by_rating.setdefault(b.rating, []).append(b.price_gbp)
    ranked = sorted(books, key=lambda b: (-b.price_gbp, b.title))
    return {
        "total_books": len(books),
        "price": {
            "min": min(prices),
            "max": max(prices),
            "mean": round(statistics.mean(prices), 2),
            "median": round(statistics.median(prices), 2),
            "stdev": round(statistics.pstdev(prices), 2),
        },
        "in_stock_count": sum(b.in_stock for b in books),
        "in_stock_pct": round(100 * sum(b.in_stock for b in books) / len(books), 1),
        "rating_distribution": {str(r): c for r, c in sorted(Counter(b.rating for b in books).items())},
        "avg_price_by_rating": {str(r): round(statistics.mean(p), 2) for r, p in sorted(by_rating.items())},
        "most_expensive": [{"title": b.title, "price_gbp": b.price_gbp} for b in ranked[:5]],
        "cheapest": [{"title": b.title, "price_gbp": b.price_gbp} for b in ranked[::-1][:5]],
    }


def render_text(summary: Dict[str, Any], meta: Dict[str, Any]) -> str:
    lines = ["WEB SCRAPING PIPELINE - SUMMARY REPORT", "=" * 40]
    for k in ("source", "pages_scraped", "requests_made", "parse_errors", "failed_pages"):
        if k in meta:
            lines.append(f"{k.replace('_', ' ').title():<16}: {meta[k]}")
    lines.append("")
    if summary.get("total_books", 0) == 0:
        lines.append("No records extracted.")
        return "\n".join(lines)
    p = summary["price"]
    lines += [
        f"Books extracted : {summary['total_books']}",
        f"In stock        : {summary['in_stock_count']} ({summary['in_stock_pct']}%)",
        f"Price (GBP)     : min {p['min']:.2f} | max {p['max']:.2f} | mean {p['mean']:.2f} | "
        f"median {p['median']:.2f} | stdev {p['stdev']:.2f}",
        "",
        "Rating  Count  Avg price",
    ]
    for r, c in summary["rating_distribution"].items():
        lines.append(f"  {r}*    {c:>5}  {summary['avg_price_by_rating'][r]:>9.2f}")
    lines += ["", "Most expensive:"]
    lines += [f"  {b['price_gbp']:>7.2f}  {b['title']}" for b in summary["most_expensive"]]
    lines += ["", "Cheapest:"]
    lines += [f"  {b['price_gbp']:>7.2f}  {b['title']}" for b in summary["cheapest"]]
    return "\n".join(lines)
