"""Command-line entry point:  python -m scraper"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path
from typing import List, Optional

from scraper import pipeline
from scraper.fetcher import Fetcher


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="scraper", description="ETL web scraper: books.toscrape.com -> CSV/JSON + summary report.")
    p.add_argument("--start-url", default=pipeline.DEFAULT_START_URL, help="first listing page (default: %(default)s)")
    p.add_argument("--max-pages", type=int, default=50, help="maximum listing pages to scrape (default: 50 = whole site)")
    p.add_argument("--delay", type=float, default=1.0, help="minimum seconds between requests (default: 1.0)")
    p.add_argument("--retries", type=int, default=3, help="retries per page on transient errors (default: 3)")
    p.add_argument("--timeout", type=float, default=10.0, help="request timeout in seconds")
    p.add_argument("--output-dir", default="output", help="directory for results (default: output)")
    p.add_argument("--ignore-robots", action="store_true", help="do not consult robots.txt (not recommended)")
    p.add_argument("-v", "--verbose", action="store_true")
    return p


def main(argv: Optional[List[str]] = None, fetcher: Optional[Fetcher] = None) -> int:
    args = build_parser().parse_args(argv)
    if args.max_pages < 1 or args.delay < 0 or args.retries < 0:
        print("scraper: --max-pages must be >= 1, --delay and --retries >= 0", file=sys.stderr)
        return 2
    logging.basicConfig(level=logging.INFO if args.verbose else logging.WARNING, format="%(levelname)s %(message)s")
    fetcher = fetcher or Fetcher(
        delay=args.delay, max_retries=args.retries, timeout=args.timeout, respect_robots=not args.ignore_robots
    )
    paths, summary = pipeline.run(fetcher, args.start_url, args.max_pages, Path(args.output_dir))
    if summary.get("total_books", 0) == 0:
        print("scraper: no records extracted (see --verbose)", file=sys.stderr)
        return 1
    print(paths["report"].read_text(encoding="utf-8"))
    print("Files written:")
    for k, v in paths.items():
        print(f"  {k:<13} {v}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
