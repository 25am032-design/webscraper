"""Transform: raw HTML -> structured records."""

from __future__ import annotations

import re
from dataclasses import asdict, dataclass
from typing import Dict, List, Optional, Tuple
from urllib.parse import urljoin

from bs4 import BeautifulSoup

RATINGS = {"One": 1, "Two": 2, "Three": 3, "Four": 4, "Five": 5}
FIELDS = ["title", "price_gbp", "rating", "in_stock", "url"]


@dataclass(frozen=True)
class Book:
    title: str
    price_gbp: float
    rating: int
    in_stock: bool
    url: str

    def to_dict(self) -> Dict[str, object]:
        return asdict(self)


def parse_price(text: str) -> float:
    cleaned = re.sub(r"[^0-9.]", "", text or "")
    if not cleaned:
        raise ValueError(f"no price found in {text!r}")
    return round(float(cleaned), 2)


def parse_rating(tag) -> int:
    for cls in tag.get("class", []):
        if cls in RATINGS:
            return RATINGS[cls]
    raise ValueError("no rating class found")


def parse_book(article, base_url: str) -> Book:
    link = article.select_one("h3 a")
    if link is None:
        raise ValueError("missing title link")
    price = article.select_one(".price_color")
    rating = article.select_one("p.star-rating")
    avail = article.select_one(".availability")
    if price is None or rating is None:
        raise ValueError("missing price or rating")
    return Book(
        title=(link.get("title") or link.get_text()).strip(),
        price_gbp=parse_price(price.get_text()),
        rating=parse_rating(rating),
        in_stock="in stock" in (avail.get_text().lower() if avail else ""),
        url=urljoin(base_url, link.get("href", "")),
    )


def parse_listing_page(html: str, page_url: str) -> Tuple[List[Book], List[str], Optional[str]]:
    """Return (books, parse_errors, next_page_url) for one listing page.

    A malformed product block is skipped and reported rather than aborting the run.
    """
    soup = BeautifulSoup(html, "html.parser")
    books: List[Book] = []
    errors: List[str] = []
    for n, article in enumerate(soup.select("article.product_pod"), start=1):
        try:
            books.append(parse_book(article, page_url))
        except ValueError as exc:
            errors.append(f"{page_url} item {n}: {exc}")
    nxt = soup.select_one("li.next a")
    next_url = urljoin(page_url, nxt["href"]) if nxt and nxt.get("href") else None
    return books, errors, next_url
