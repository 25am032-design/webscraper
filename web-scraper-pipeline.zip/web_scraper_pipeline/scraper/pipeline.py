"""Extract -> Transform -> Load orchestration."""

from __future__ import annotations

import csv
import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Tuple

from scraper import report
from scraper.fetcher import FetchError, Fetcher
from scraper.parser import FIELDS, Book, parse_listing_page

log = logging.getLogger(__name__)

DEFAULT_START_URL = "https://books.toscrape.com/catalogue/page-1.html"


def extract_transform(fetcher: Fetcher, start_url: str, max_pages: int) -> Tuple[List[Book], Dict[str, Any]]:
    books: Dict[str, Book] = {}  # keyed by url -> de-duplicates
    parse_errors: List[str] = []
    failed: List[str] = []
    pages = 0
    url = start_url
    seen_pages = set()
    while url and pages < max_pages and url not in seen_pages:
        seen_pages.add(url)
        try:
            html = fetcher.get(url)
        except FetchError as exc:
            log.error("skipping page: %s", exc)
            failed.append(str(exc))
            break  # next-page link is unknown without this page
        page_books, errs, next_url = parse_listing_page(html, url)
        url = next_url
        pages += 1
        parse_errors += errs
        for b in page_books:
            books.setdefault(b.url, b)
        log.info("page %d: %d books", pages, len(page_books))
    meta = {
        "source": start_url,
        "pages_scraped": pages,
        "requests_made": fetcher.requests_made,
        "parse_errors": len(parse_errors),
        "failed_pages": len(failed),
        "parse_error_details": parse_errors,
        "failed_details": failed,
    }
    return list(books.values()), meta


def load(books: List[Book], summary: Dict[str, Any], meta: Dict[str, Any], out_dir: Path, prefix: str = "") -> Dict[str, Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    paths = {
        "csv": out_dir / f"{prefix}books.csv",
        "json": out_dir / f"{prefix}books.json",
        "report": out_dir / f"{prefix}summary_report.txt",
        "summary_json": out_dir / f"{prefix}summary.json",
    }
    with open(paths["csv"], "w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(b.to_dict() for b in books)
    paths["json"].write_text(json.dumps([b.to_dict() for b in books], indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    paths["summary_json"].write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    paths["report"].write_text(report.render_text(summary, meta) + "\n", encoding="utf-8")
    return paths


def run(fetcher: Fetcher, start_url: str, max_pages: int, out_dir: Path, prefix: str = "") -> Tuple[Dict[str, Path], Dict[str, Any]]:
    books, meta = extract_transform(fetcher, start_url, max_pages)
    summary = report.summarize(books)
    return load(books, summary, meta, out_dir, prefix), summary
