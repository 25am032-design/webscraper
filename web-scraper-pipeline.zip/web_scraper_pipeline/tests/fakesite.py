"""Offline stand-in for books.toscrape.com: same markup, deterministic data, no network."""

from __future__ import annotations

from typing import Dict, List, Optional

BASE = "https://books.toscrape.com/catalogue/"
WORDS = ["Attic", "Velvet", "Orchard", "Tiger", "Harbour", "Cipher", "Meadow", "Lantern", "Compass", "Ember"]
RATING_NAMES = ["One", "Two", "Three", "Four", "Five"]


def make_books(n: int) -> List[dict]:
    books = []
    for i in range(n):
        title = f"The {WORDS[i % len(WORDS)]} Chronicle {i + 1}"
        books.append({
            "title": title,
            "price": f"£{10 + (i * 7.31) % 50:.2f}",
            "rating": RATING_NAMES[(i * 3) % 5],
            "stock": "In stock" if i % 4 else "Out of stock",
            "href": f"the-{WORDS[i % len(WORDS)].lower()}-chronicle-{i + 1}_{1000 + i}/index.html",
        })
    return books


def article(b: dict) -> str:
    cls = "instock availability" if b["stock"] == "In stock" else "outofstock availability"
    return (
        '<li class="col-xs-6"><article class="product_pod">'
        f'<div class="image_container"><a href="{b["href"]}"><img alt="{b["title"]}"></a></div>'
        f'<p class="star-rating {b["rating"]}"><i class="icon-star"></i></p>'
        f'<h3><a href="{b["href"]}" title="{b["title"]}">{b["title"][:20]}...</a></h3>'
        f'<div class="product_price"><p class="price_color">{b["price"]}</p>'
        f'<p class="{cls}"><i class="icon-ok"></i>\n    {b["stock"]}\n</p></div>'
        "</article></li>"
    )


def page_html(books: List[dict], next_href: Optional[str]) -> str:
    nxt = f'<ul class="pager"><li class="next"><a href="{next_href}">next</a></li></ul>' if next_href else ""
    return f"<html><body><ol class='row'>{''.join(article(b) for b in books)}</ol>{nxt}</body></html>"


def make_site(pages: int = 3, per_page: int = 5) -> Dict[str, str]:
    """Map URL -> HTML for `pages` listing pages."""
    all_books = make_books(pages * per_page)
    site = {}
    for p in range(1, pages + 1):
        chunk = all_books[(p - 1) * per_page: p * per_page]
        nxt = f"page-{p + 1}.html" if p < pages else None
        site[f"{BASE}page-{p}.html"] = page_html(chunk, nxt)
    return site


class FakeResponse:
    def __init__(self, status=200, text="", headers=None):
        self.status_code, self.text, self.headers, self.encoding = status, text, headers or {}, None


class FakeSession:
    """Quacks like requests.Session. `script` maps url -> list of responses/exceptions to serve in order."""

    def __init__(self, site: Dict[str, str], script: Optional[Dict[str, list]] = None, robots: Optional[str] = None):
        self.site, self.script = site, script or {}
        self.robots = robots
        self.headers: Dict[str, str] = {}
        self.calls: List[str] = []

    def get(self, url, timeout=None):
        self.calls.append(url)
        if url.endswith("/robots.txt"):
            return FakeResponse(200, self.robots) if self.robots is not None else FakeResponse(404)
        queue = self.script.get(url)
        if queue:
            item = queue.pop(0)
            if isinstance(item, Exception):
                raise item
            return item
        if url in self.site:
            return FakeResponse(200, self.site[url])
        return FakeResponse(404)
