import csv
import json

import pytest
import requests

from scraper import cli, pipeline, report
from scraper.fetcher import FetchError, Fetcher
from scraper.parser import Book, parse_listing_page, parse_price, parse_rating
from tests.fakesite import BASE, FakeResponse, FakeSession, make_books, make_site, page_html

START = BASE + "page-1.html"


class Clock:
    """Fake time so tests never really sleep."""

    def __init__(self):
        self.now, self.sleeps = 0.0, []

    def sleep(self, s):
        self.sleeps.append(s)
        self.now += s

    def __call__(self):
        return self.now


def make_fetcher(session, clock=None, **kw):
    clock = clock or Clock()
    kw.setdefault("respect_robots", False)
    return Fetcher(session=session, sleep=clock.sleep, clock=clock, **kw), clock


# ---------------- parser ----------------

def test_parse_price_variants():
    assert parse_price("£51.77") == 51.77
    assert parse_price("Â£12.50") == 12.5   # mojibake from wrong encoding
    with pytest.raises(ValueError):
        parse_price("free")


def test_parse_rating_missing():
    from bs4 import BeautifulSoup
    tag = BeautifulSoup('<p class="star-rating Four"></p>', "html.parser").p
    assert parse_rating(tag) == 4
    with pytest.raises(ValueError):
        parse_rating(BeautifulSoup('<p class="star-rating"></p>', "html.parser").p)


def test_parse_listing_page_fields_and_next():
    html = page_html(make_books(5), "page-2.html")
    books, errors, nxt = parse_listing_page(html, START)
    assert len(books) == 5 and errors == []
    assert nxt == BASE + "page-2.html"
    b = books[0]
    assert b.title == "The Attic Chronicle 1"          # full title from title attr, not truncated text
    assert b.url.startswith(BASE) and b.url.endswith("index.html")
    assert isinstance(b.price_gbp, float) and 1 <= b.rating <= 5
    assert books[0].in_stock is False and books[1].in_stock is True


def test_parse_last_page_has_no_next():
    _, _, nxt = parse_listing_page(page_html(make_books(2), None), START)
    assert nxt is None


def test_malformed_item_is_skipped_and_reported():
    html = ("<article class='product_pod'><h3><a href='x' title='Broken'></a></h3></article>"
            + page_html(make_books(1), None))
    books, errors, _ = parse_listing_page(html, START)
    assert len(books) == 1 and len(errors) == 1 and "item 1" in errors[0]


def test_article_without_link_reported():
    _, errors, _ = parse_listing_page("<article class='product_pod'></article>", START)
    assert "missing title link" in errors[0]


# ---------------- fetcher ----------------

def test_custom_headers_sent():
    s = FakeSession({START: "ok"})
    make_fetcher(s)
    assert "EducationalScraper" in s.headers["User-Agent"]


def test_rate_limiting_enforces_delay():
    s = FakeSession(make_site(3))
    f, clock = make_fetcher(s, delay=2.0)
    for p in (1, 2, 3):
        f.get(BASE + f"page-{p}.html")
    assert clock.sleeps == [2.0, 2.0]


def test_retry_then_success_uses_exponential_backoff():
    s = FakeSession({START: "<html>ok</html>"}, script={START: [FakeResponse(503), FakeResponse(429)]})
    f, clock = make_fetcher(s, delay=0, backoff=2.0)
    assert f.get(START) == "<html>ok</html>"
    assert f.requests_made == 3
    assert [x for x in clock.sleeps if x] == [1.0, 2.0]


def test_retry_on_network_errors():
    s = FakeSession({START: "ok"}, script={START: [requests.ConnectionError("boom"), requests.Timeout("slow")]})
    f, _ = make_fetcher(s, delay=0)
    assert f.get(START) == "ok"


def test_retry_after_header_honoured():
    s = FakeSession({START: "ok"}, script={START: [FakeResponse(429, headers={"Retry-After": "7"})]})
    f, clock = make_fetcher(s, delay=0)
    f.get(START)
    assert 7 in clock.sleeps


def test_gives_up_after_max_retries():
    s = FakeSession({}, script={START: [FakeResponse(500)] * 10})
    f, _ = make_fetcher(s, delay=0, max_retries=2)
    with pytest.raises(FetchError, match="giving up after 3 attempts"):
        f.get(START)
    assert f.requests_made == 3


def test_non_retryable_status_fails_immediately():
    f, _ = make_fetcher(FakeSession({}), delay=0)
    with pytest.raises(FetchError, match="HTTP 404"):
        f.get(START)
    assert f.requests_made == 1


def test_robots_disallow_respected():
    s = FakeSession(make_site(1), robots="User-agent: *\nDisallow: /catalogue/")
    f, _ = make_fetcher(s, delay=0, respect_robots=True)
    with pytest.raises(FetchError, match="robots.txt disallows"):
        f.get(START)
    assert START not in s.calls


def test_robots_allow_and_cached():
    s = FakeSession(make_site(2), robots="User-agent: *\nDisallow: /private/")
    f, _ = make_fetcher(s, delay=0, respect_robots=True)
    f.get(START)
    f.get(BASE + "page-2.html")
    assert s.calls.count("https://books.toscrape.com/robots.txt") == 1


def test_missing_robots_means_allowed():
    f, _ = make_fetcher(FakeSession(make_site(1)), delay=0, respect_robots=True)
    assert f.get(START)


def test_robots_network_error_means_allowed():
    s = FakeSession(make_site(1), script={"https://books.toscrape.com/robots.txt": [requests.ConnectionError("x")]})
    f, _ = make_fetcher(s, delay=0, respect_robots=True)
    assert f.get(START)


# ---------------- pipeline ----------------

def test_full_pipeline_writes_csv_json_and_report(tmp_path):
    f, _ = make_fetcher(FakeSession(make_site(3, 5)), delay=0)
    paths, summary = pipeline.run(f, START, 10, tmp_path)
    assert summary["total_books"] == 15
    rows = list(csv.DictReader(open(paths["csv"], encoding="utf-8")))
    assert len(rows) == 15 and set(rows[0]) == {"title", "price_gbp", "rating", "in_stock", "url"}
    assert len(json.loads(paths["json"].read_text())) == 15
    assert "SUMMARY REPORT" in paths["report"].read_text()
    assert json.loads(paths["summary_json"].read_text())["total_books"] == 15


def test_max_pages_limits_scrape(tmp_path):
    f, _ = make_fetcher(FakeSession(make_site(5, 5)), delay=0)
    _, summary = pipeline.run(f, START, 2, tmp_path)
    assert summary["total_books"] == 10


def test_duplicates_removed():
    site = make_site(1, 5)
    site[BASE + "page-2.html"] = site[START]  # same books again
    site[START] = site[START].replace("</ol>", "</ol><li class='next'><a href='page-2.html'>n</a></li>", 1)
    f, _ = make_fetcher(FakeSession(site), delay=0)
    books, meta = pipeline.extract_transform(f, START, 5)
    assert len(books) == 5


def test_pagination_loop_guard():
    site = {START: page_html(make_books(2), "page-1.html")}  # next points to itself
    f, _ = make_fetcher(FakeSession(site), delay=0)
    books, meta = pipeline.extract_transform(f, START, 50)
    assert meta["pages_scraped"] == 1 and len(books) == 2


def test_failed_page_is_reported_and_partial_results_kept():
    site = make_site(3, 5)
    s = FakeSession(site, script={BASE + "page-2.html": [FakeResponse(500)] * 10})
    f, _ = make_fetcher(s, delay=0, max_retries=1)
    books, meta = pipeline.extract_transform(f, START, 10)
    assert len(books) == 5 and meta["failed_pages"] == 1 and meta["pages_scraped"] == 1


# ---------------- report ----------------

def test_summary_statistics():
    books = [Book("A", 10.0, 5, True, "u1"), Book("B", 20.0, 5, False, "u2"), Book("C", 30.0, 1, True, "u3")]
    s = report.summarize(books)
    assert s["price"] == {"min": 10.0, "max": 30.0, "mean": 20.0, "median": 20.0, "stdev": 8.16}
    assert s["rating_distribution"] == {"1": 1, "5": 2}
    assert s["avg_price_by_rating"] == {"1": 30.0, "5": 15.0}
    assert s["in_stock_pct"] == 66.7
    assert s["most_expensive"][0]["title"] == "C" and s["cheapest"][0]["title"] == "A"


def test_empty_summary_and_text():
    s = report.summarize([])
    assert s == {"total_books": 0}
    assert "No records" in report.render_text(s, {"source": "x"})


# ---------------- CLI ----------------

def test_cli_success(tmp_path, capsys):
    f, _ = make_fetcher(FakeSession(make_site(2, 5)), delay=0)
    code = cli.main(["--output-dir", str(tmp_path), "--max-pages", "5", "-v"], fetcher=f)
    out = capsys.readouterr().out
    assert code == 0 and "Books extracted : 10" in out and (tmp_path / "books.csv").exists()


def test_cli_no_records_exit_1(tmp_path, capsys):
    f, _ = make_fetcher(FakeSession({}), delay=0)
    assert cli.main(["--output-dir", str(tmp_path)], fetcher=f) == 1


@pytest.mark.parametrize("arg", [["--max-pages", "0"], ["--delay", "-1"], ["--retries", "-1"]])
def test_cli_rejects_bad_args(arg):
    assert cli.main(arg) == 2


def test_cli_builds_real_fetcher_by_default(tmp_path, monkeypatch, capsys):
    monkeypatch.setattr(cli, "Fetcher", lambda **kw: make_fetcher(FakeSession(make_site(1, 3)), delay=0)[0])
    assert cli.main(["--output-dir", str(tmp_path)]) == 0
